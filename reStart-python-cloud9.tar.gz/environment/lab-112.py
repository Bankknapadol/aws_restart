myMixedTypeList = [45,290578,1.02,True,"My cat is the best.","45"]

for item in myMixedTypeList:
    print("{} is of the of the data type {}".format(item,type(item)))